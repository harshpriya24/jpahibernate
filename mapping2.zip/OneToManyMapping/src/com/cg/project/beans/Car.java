package com.cg.project.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Car {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int carCode;
private String carModel;
private int price;
@OneToOne(mappedBy="car")
private  Customer customer;
public Car() {}
 
public Car(int carCode, String carModel, int price, Customer customer) {
	super();
	this.carCode = carCode;
	this.carModel = carModel;
	this.price = price;
	this.customer = customer;
}

public int getCarCode() {
	return carCode;
}
public void setCarCode(int carCode) {
	this.carCode = carCode;
}
public String getCarModel() {
	return carModel;
}
public void setCarModel(String carModel) {
	this.carModel = carModel;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public Customer getCustomer() {
	return customer;
}
public void setCustomer(Customer customer) {
	this.customer = customer;
}

}
